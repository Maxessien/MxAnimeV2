# mal-nyaa

Find [nyaa.si](https://nyaa.si) torrents for a MyAnimeList anime episode and get them back as structured objects.

```bash
npm install mal-nyaa
```

## Usage

```ts
import { findTorrents } from "mal-nyaa";

const torrents = await findTorrents(
  { malId: 52991, episode: 5, season: 1 },
  { resolutions: ["1080p"], excludeRemakes: true },
);
```

Runs anywhere with `fetch` (Node 18+, Bun, Deno, edge workers). Browsers are blocked by nyaa (CORS), so run it server-side.

### Result

```jsonc
{
  "title": "[SubsPlease] Sousou no Frieren - 05 (1080p) [8E3F8FA5].mkv",
  "nyaaId": 1712345,
  "pageUrl": "https://nyaa.si/view/1712345",
  "torrentUrl": "https://nyaa.si/download/1712345.torrent",
  "magnet": "magnet:?xt=urn:btih:...",
  "infoHash": "…",
  "size": "1.4 GiB", "sizeBytes": 1503238554,
  "date": "2023-10-06T15:00:00.000Z",
  "seeders": 116, "leechers": 2, "downloads": 31000, "comments": 3,
  "categoryId": "1_2", "category": "Anime - English-translated",
  "trusted": true, "remake": false,
  "releaseGroup": "SubsPlease", "resolution": "1080p",
  "episode": 5, "episodeRange": null, "season": null, "version": null,
  "isBatch": false, "codec": null, "source": null, "audio": [], "subtitles": [],
  "bitDepth": null, "crc32": "8E3F8FA5", "container": "mkv",
  "isDub": false, "isDualAudio": false
}
```

### Options

| option | default | |
|---|---|---|
| `includeBatches` | `false` | include batch releases covering the episode |
| `trustedOnly` | `false` | trusted uploaders only |
| `excludeRemakes` | `false` | drop remakes |
| `resolutions` | all | e.g. `["1080p","720p"]` |
| `category` | `"1_2"` | nyaa category (`"1_0"` = all anime) |
| `baseUrl` | `https://nyaa.si` | mirror |
| `titles` | from MAL | skip MAL lookup |
| `maxTitles` | `4` | title variants to search |
| `requestDelayMs` | `300` | delay between requests |
| `timeoutMs` | `15000` | per request |
| `fetch` | global | custom fetch |

Also exported: `parseTitle`, `parseRss`, `parseHtml`, `searchNyaa`, `getAnimeInfo`, `filterTorrents`, and error classes `AnimeNotFoundError`, `NetworkError`, `RateLimitError`.

Titles come from MyAnimeList via the Jikan API (with a fallback to the MAL page). Results are filtered so only the requested episode/season remain, deduped by info hash and sorted by seeders.

## License
MIT
