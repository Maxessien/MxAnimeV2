# Changelog

## 0.1.0

- First release as `@maxessien/seedr`.
- Sign-in with password, device code, or existing tokens; automatic refresh and `onTokenRefresh` hook.
- Tasks: add by magnet, `.torrent` file or URL; list, get, delete; `waitForTask` with progress, timeout, abort and failure detection.
- Folders: list, tree, find, create, rename, move, delete.
- Files: download links, folder archives, HLS/thumbnail links, rename, move, bulk delete.
- Account: storage, plan, settings, devices, wishlist.
- Typed errors, retries with jittered backoff and `Retry-After`, timeouts and `AbortSignal` everywhere, zod input and response checks.
- Dual ESM/CJS build with type definitions.
