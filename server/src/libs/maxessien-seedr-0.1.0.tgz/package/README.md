# @maxessien/seedr

Typed, reliable TypeScript SDK for [Seedr.cc](https://www.seedr.cc): sign-in, tasks (torrents), files, folders and account.

- Runs on Node 18+, Bun, Deno and edge runtimes. Uses only `fetch`; zod is the single dependency.
- Dual ESM + CommonJS build with full type definitions.
- Typed errors, automatic token refresh, retries with jittered backoff, timeouts and `AbortSignal` on every call.

## Install

```bash
npm install @maxessien/seedr
# or: bun add @maxessien/seedr / pnpm add @maxessien/seedr
```

## Quick start

```ts
import { SeedrClient } from "@maxessien/seedr";

const seedr = await SeedrClient.login("me@example.com", "password");

const { user_torrent_id } = await seedr.tasks.addMagnet("magnet:?xt=urn:btih:...");
const folder = await seedr.tasks.waitForTask(user_torrent_id!, {
  onProgress: (s) => console.log(`${s.stage} ${s.progress}%`),
});

const contents = await seedr.folders.list(folder!.id);
const link = await seedr.files.getDownloadUrl(contents.files[0]!.folder_file_id);
console.log(link.url);
```

## Signing in

```ts
// 1. Email + password
const seedr = new SeedrClient();
await seedr.auth.loginWithPassword("me@example.com", "password");

// 2. Device code (the official TV / Kodi pairing flow)
const code = await seedr.auth.requestDeviceCode();
console.log(`Open ${code.verification_url} and enter ${code.user_code}`);
let tokens;
while (!(tokens = await seedr.auth.checkDeviceCode(code.device_code))) {
  await new Promise((r) => setTimeout(r, (code.interval ?? 5) * 1000));
}

// 3. Existing tokens
const seedr2 = new SeedrClient({
  tokens: { accessToken: "...", refreshToken: "...", clientId: "seedr_chrome" },
  onTokenRefresh: async (t) => saveToDb(t), // persist new tokens
});
// or simply: new SeedrClient({ accessToken: "..." })
```

Expired tokens refresh automatically (shortly before expiry, and once after a 401). Concurrent calls share a single refresh. Plug in your own persistence with a `TokenStore` (`get()` / `set()` / `clear()`).

## Tasks

```ts
await seedr.tasks.addMagnet(magnet, { folderId: 123 });
await seedr.tasks.addTorrentFile(buffer);          // Buffer, Uint8Array, Blob, or a file path in Node
await seedr.tasks.addTorrentUrl("https://example.com/file.torrent");
await seedr.tasks.addAuto(magnetOrUrlOrFile);       // picks the right one

const active = await seedr.tasks.list();            // TaskStatus[]
const one = await seedr.tasks.get(id);              // progress, stage, downloadRate, seeders, leechers
await seedr.tasks.delete(id);                       // cancel / remove

const folder = await seedr.tasks.waitForTask(id, {
  intervalMs: 5000,       // default 5s, min 1s
  timeoutMs: 3_600_000,   // default 6h -> TimeoutError
  onProgress: (s) => {},
  signal: controller.signal,
});
```

Stages: `queued`, `downloading`, `stalled`, `finishing`, `completed`, `failed`. A task that Seedr stops with warnings makes `waitForTask` throw `ApiError` with `code: "task_failed"`.

## Folders

```ts
await seedr.folders.root();
await seedr.folders.list(folderId);
await seedr.folders.tree(undefined, { maxDepth: 3 });   // nested TreeNode with sizes and paths
await seedr.folders.find(/\.mkv$/i);                    // FoundItem[]
await seedr.folders.create("Movies");
await seedr.folders.rename(id, "New name");
await seedr.folders.move([id1, id2], targetFolderId);
await seedr.folders.delete([id1, id2]);
```

## Files and links

```ts
await seedr.files.getDownloadUrl(fileId);        // { url, name, size }
await seedr.files.getFolderArchiveUrl(folderId); // zip of a whole folder
await seedr.files.getStreamLinks(fileId);        // { hls, preview, thumbnail }
await seedr.files.rename(fileId, "name.mkv");
await seedr.files.move(fileId, targetFolderId);
await seedr.files.delete([fileId1, fileId2]);
await seedr.files.deleteMany([{ type: "file", id: 1 }, { type: "folder", id: 2 }]);
```

## Account

```ts
await seedr.account.storage();   // space_used, space_max, free, percentUsed
await seedr.account.plan();      // premium, spaceMax, bandwidthMax, username
await seedr.account.settings();
await seedr.account.devices();
await seedr.account.wishlist();
await seedr.account.removeWishlistItem(id);
```

## Errors

Every error extends `SeedrError` and carries `status`, `code` and the raw `response`.

| Class | When |
| --- | --- |
| `AuthError` | 401/403, bad credentials, expired refresh token |
| `RateLimitError` | 429 (has `retryAfterMs`) |
| `NotFoundError` | 404, unknown task |
| `QuotaExceededError` | not enough storage |
| `ValidationError` | bad input (checked before sending) or an unexpected response shape |
| `NetworkError` | fetch failed |
| `TimeoutError` | request or `waitForTask` timed out |
| `ApiError` | anything else (5xx, `result: false`) |

```ts
import { QuotaExceededError } from "@maxessien/seedr";
try { await seedr.tasks.addMagnet(m); }
catch (e) { if (e instanceof QuotaExceededError) console.log("Storage full"); }
```

## Reliability options

```ts
new SeedrClient({
  timeoutMs: 30_000,                                         // per request
  retry: { attempts: 4, baseDelayMs: 300, maxDelayMs: 10_000 },
  fetch: customFetch,                                        // e.g. undici, or a mock in tests
  baseUrl: "https://www.seedr.cc",
});
```

Only safe (read) operations are retried; adding, renaming, moving and deleting are never retried automatically. `Retry-After` is honored. Every method accepts `{ signal, timeoutMs }` as its last argument.

## Utilities

`parseMagnet`, `isMagnet`, `formatBytes`.

## Publishing to npm

1. Sign in: `npm login` (your account must own the `@maxessien` scope, which is your username).
2. Bump the version in `package.json` and add a CHANGELOG entry.
3. From `packages/seedr`: `npm publish` — `prepublishOnly` runs typecheck, tests and the build first. `publishConfig.access` is already `public`.
4. Check what ships beforehand with `npm pack --dry-run`.

## License

MIT
